import json
import boto3

def lambda_handler(event, context):
    print("Lambda was triggered!")
    s3 = boto3.client('s3')
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    metadata = s3.head_object(Bucket=bucket, Key=key)
    print(f"File uploaded: {key}, Size: {metadata['ContentLength']} bytes")
    return {
        'statusCode': 200,
        'body': json.dumps('Logged successfully.')
    }